import bpy
from bpy.types import AddonPreferences
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from .utils import _AXIS_ITEMS, _ROTATION_ITEMS

QUALITY_PRESET_ITEMS = [
    ("DRAFT",      "草稿",      "快速细分，三角面数少，曲面可见棱角"),
    ("BALANCED",   "均衡",      "质量适中，三角面数适中"),
    ("FINE",       "精细",      "高质量，速度较慢，适合关键部件或特写"),
    ("ULTRA_FINE", "超精细",    "最高质量，速度最慢，适合极端特写"),
    ("CUSTOM",     "自定义",    "手动设置线性公差和角度公差"),
]

QUALITY_PRESETS = {
    "DRAFT":      (0.05, 0.6),
    "BALANCED":   (0.01, 0.25),
    "FINE":       (0.002, 0.1),
    "ULTRA_FINE": (0.0005, 0.05),
}


def _apply_preset(self, context):
    if self.tol_preset in QUALITY_PRESETS:
        linear, angular = QUALITY_PRESETS[self.tol_preset]
        self.tol_linear = linear
        self.tol_angular = angular


class STEPImporterPreferences(AddonPreferences):
    bl_idname = __package__

    import_materials: BoolProperty(
        name="导入材质",
        description="导入时应用 STEP 文件中的材质颜色",
        default=True,
    )

    default_up_axis: EnumProperty(
        name="源文件朝上轴",
        description="模型来源的 CAD 应用中哪个轴朝上。大多数 CAD 软件默认为 Y 轴。如果导入后模型侧躺，请切换为 Z 轴",
        items=_AXIS_ITEMS,
        default="Y",
    )

    default_rotation: EnumProperty(
        name="默认旋转",
        description="朝上轴校正后绕垂直轴的默认旋转角度",
        items=_ROTATION_ITEMS,
        default="0",
    )

    tol_linear: bpy.props.FloatProperty(
        name="线性公差",
        description="网格与真实 CAD 曲面之间的最大距离。在相对模式下，表示为每条边长度的分数。值越小，几何体越光滑，三角面越多",
        default=0.01,
        min=0.001,
    )

    tol_angular: bpy.props.FloatProperty(
        name="角度公差",
        description="相邻三角面之间的最大角度（弧度）。独立于零件大小控制曲线平滑度——较小的值可使大小零件的曲线都保持平滑",
        default=0.5,
        min=0.001,
    )

    tol_relative: BoolProperty(
        name="相对公差",
        description="启用时，线性公差将按每个特征的大小进行缩放，而非使用固定的世界空间距离。推荐用于包含不同大小零件的装配体",
        default=True,
    )

    tol_preset: EnumProperty(
        name="质量预设",
        description="细分质量；越高的质量产生越平滑的曲线和越多的三角面",
        items=QUALITY_PRESET_ITEMS,
        default="BALANCED",
        update=_apply_preset,
    )

    shade_smooth: BoolProperty(
        name="平滑着色",
        description="自动对导入的网格应用平滑着色",
        default=True,
    )

    cleanup_topology: BoolProperty(
        name="清理拓扑",
        description="清理导入的拓扑结构（移除重合顶点、合并临近顶点等）。可能会增加导入时间，但有助于处理有问题的 STEP 文件",
        default=False,
    )

    ct_doubles: BoolProperty(
        name="移除重合顶点",
        description="移除距离非常接近的重复顶点",
        default=True,
    )

    ct_doubles_dist: bpy.props.FloatProperty(
        name="重合距离",
        description="移除重复顶点的距离阈值",
        precision=5,
        default=0.0001,
        min=0.00001,
        max=1.0,
    )

    ct_dissolve: BoolProperty(
        name="溶解共面面",
        description="溶解共面的面以简化网格",
        default=True,
    )

    ct_dissolve_angle: bpy.props.FloatProperty(
        name="溶解角度",
        description="溶解共面面的角度阈值（度）",
        default=0.5,
        min=0.1,
        max=180.0,
    )

    show_progress: BoolProperty(
        name="显示导入进度",
        description="在导入过程中在 3D 视口中显示 GPU 进度条",
        default=True,
    )

    default_scale: FloatProperty(
        name="默认缩放",
        description="应用于导入几何体的统一缩放倍数。如果模型应为米却导入为毫米，使用 1000；反之使用 0.001",
        default=1.0,
        min=0.0001,
        max=10000.0,
        soft_min=0.001,
        soft_max=1000.0,
    )

    default_placement: EnumProperty(
        name="默认放置位置",
        description="导入对象在场景中的放置位置",
        items=[
            ("ORIGIN", "世界原点", "放置在 Blender 世界原点"),
            ("CURSOR", "3D 光标", "放置在当前 3D 光标位置"),
        ],
        default="ORIGIN",
    )
    
    default_origin_offset: EnumProperty(
        name="默认原点偏移",
        description="应用于导入对象原点的默认偏移",
        items=[
            ("KEEP", "保持", "保留 CAD 文件中的原始位置"),
            ("CENTERXY", "居中 XY", "将导入模型在 X 和 Y 轴上居中，同时保留原始高度"),
            ("CENTERXYZ", "居中 XYZ", "将导入模型在 X、Y 和 Z 轴上居中"),
            ("BOTTOM", "底部居中", "将导入模型在 X 和 Y 轴上居中，并将其最低点放置在世界 Z=0 平面上"),
        ],
        default="KEEP",
    )

    use_assembly_collections: BoolProperty(
        name="装配集合",
        description="将导入的零件组织到嵌套的 Blender 集合中，匹配 STEP 装配层级",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        # ── 默认变换 ─────────────────────────────────────────────────────
        layout.label(text="默认变换")
        layout.prop(self, "default_up_axis", text="源文件朝上轴")
        layout.prop(self, "default_rotation")
        layout.prop(self, "default_scale")
        layout.prop(self, "default_placement")
        layout.prop(self, "default_origin_offset")
        layout.separator()

        # ── 质量与外观 ───────────────────────────────────────────────────
        layout.label(text="质量与外观")
        layout.prop(self, "tol_preset")
        if self.tol_preset == "CUSTOM":
            layout.prop(self, "tol_linear")
            layout.prop(self, "tol_angular")
        layout.prop(self, "tol_relative")
        layout.prop(self, "import_materials")
        layout.prop(self, "shade_smooth")
        layout.separator()

        # ── 结构 ─────────────────────────────────────────────────────────
        layout.label(text="结构")
        layout.prop(self, "use_assembly_collections")
        layout.prop(self, "show_progress")
        layout.separator()

        # ── 清理 ─────────────────────────────────────────────────────────
        layout.label(text="清理")
        layout.prop(self, "cleanup_topology")
        if self.cleanup_topology:
            box = layout.box()
            box.prop(self, "ct_doubles")
            if self.ct_doubles:
                box.prop(self, "ct_doubles_dist")
            box.prop(self, "ct_dissolve")
            if self.ct_dissolve:
                box.prop(self, "ct_dissolve_angle")


def register():
    bpy.utils.register_class(STEPImporterPreferences)


def unregister():
    bpy.utils.unregister_class(STEPImporterPreferences)
