import os
import traceback

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from .importer import import_step
from .utils import cascadio_available, _AXIS_ITEMS, _ROTATION_ITEMS

# (prop_name, UI label, skip-by-default, name prefixes to match, tooltip)
_CONSTRUCTION_FILTERS = [
    (
        "skip_axes",
        "坐标轴",
        True,
        ("axes", "axis"),
        "坐标轴指示对象（Axes、Axis001…）",
    ),
    (
        "skip_sketches",
        "草图",
        True,
        ("sketch",),
        "参数化历史中的草图对象",
    ),
    ("skip_lines", "线条", True, ("line", "arc"), "构造线/圆弧对象"),
    (
        "skip_hatches",
        "填充图案",
        True,
        ("hatch",),
        "建筑图纸中使用的 2D 填充图案",
    ),
    (
        "skip_wall_traces",
        "墙体轮廓",
        False,
        ("walltrace", "wall_trace"),
        "墙体描边/注释对象",
    ),
    ("skip_wires", "线框", False, ("wire",), "线框/仅边线对象"),
    (
        "skip_rectangles",
        "矩形",
        False,
        ("rectangle",),
        "矩形草图对象",
    ),
    (
        "skip_extrudes",
        "拉伸历史",
        False,
        ("extrude",),
        "FreeCAD 拉伸操作历史对象",
    ),
    (
        "skip_cuts",
        "切割/凹槽",
        False,
        ("cut", "pocket", "chamfer"),
        "切割、凹槽和倒角操作对象",
    ),
    (
        "skip_terrain",
        "地形/场地",
        False,
        ("terrain", "topography", "site"),
        "地形、地形和场地对象",
    ),
]


class ImportSTEPOperator(Operator, ImportHelper):
    """将 STEP 或 IGES 文件导入当前场景"""

    bl_idname = "import_scene.step"
    bl_label = "导入 STEP/IGES"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".step"
    filter_glob: StringProperty(
        default="*.step;*.stp;*.iges;*.igs",
        options={"HIDDEN"},
    )

    filepath: StringProperty(
        subtype="FILE_PATH",
        options={"HIDDEN", "SKIP_SAVE"},
    )

    # Multi-file drop support — populated by FileHandler for multi-drop
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={"HIDDEN", "SKIP_SAVE"},
    )
    directory: StringProperty(
        subtype="DIR_PATH",
        options={"HIDDEN", "SKIP_SAVE"},
    )

    up_axis: EnumProperty(
        name="源文件朝上轴",
        description="模型来源的 CAD 应用中哪个轴朝上。大多数 CAD 软件默认为 Y 轴。如果导入后模型侧躺，请尝试切换为 Z 轴",
        items=_AXIS_ITEMS,
        default="Y",
    )

    rotation_deg: EnumProperty(
        name="旋转",
        description="朝上轴校正后绕垂直轴的旋转角度",
        items=_ROTATION_ITEMS,
        default="0",
    )

    placement: EnumProperty(
        name="放置位置",
        description="导入对象在场景中的放置位置",
        items=[
            ("ORIGIN", "世界原点", "放置在 Blender 世界原点"),
            ("CURSOR", "3D 光标", "放置在当前 3D 光标位置"),
        ],
        default="ORIGIN",
    )

    scale: FloatProperty(
        name="缩放",
        description="应用于导入几何体的统一缩放倍数。正确导出的文件保持 1.0。如果模型应为米却导入为毫米，使用 1000；反之使用 0.001",
        default=1.0,
        min=0.0001,
        max=10000.0,
        soft_min=0.001,
        soft_max=1000.0,
    )
    
    origin_offset: EnumProperty(
        name="原点偏移",
        description="调整导入装配体相对于所选放置位置的偏移。不会改变对象原点",
        items=[
            ("KEEP", "保持", "保留 CAD 文件中的原始位置"),
            ("CENTERXY", "居中 XY", "将导入模型在 X 和 Y 轴上居中，同时保留原始高度"),
            ("CENTERXYZ", "居中 XYZ", "将导入模型在 X、Y 和 Z 轴上居中"),
            ("BOTTOM", "底部居中", "将导入模型在 X 和 Y 轴上居中，并将其最低点放置在世界 Z=0 平面上")
        ],
        default="KEEP",
    )

    merge_objects: BoolProperty(
        name="合并实体",
        description="将所有导入的实体合并为单个网格对象",
        default=False,
    )

    use_assembly_collections: BoolProperty(
        name="装配集合",
        description="将导入的零件组织到嵌套的 Blender 集合中，匹配 STEP 装配层级。合并实体启用时此项无效",
        default=False,
    )

    # ── Construction geometry filters ─────────────────────────────────────────
    skip_axes: BoolProperty(
        name="坐标轴", description=_CONSTRUCTION_FILTERS[0][4], default=True
    )
    skip_sketches: BoolProperty(
        name="草图", description=_CONSTRUCTION_FILTERS[1][4], default=True
    )
    skip_lines: BoolProperty(
        name="线条", description=_CONSTRUCTION_FILTERS[2][4], default=True
    )
    skip_hatches: BoolProperty(
        name="填充图案", description=_CONSTRUCTION_FILTERS[3][4], default=True
    )
    skip_wall_traces: BoolProperty(
        name="墙体轮廓", description=_CONSTRUCTION_FILTERS[4][4], default=False
    )
    skip_wires: BoolProperty(
        name="线框", description=_CONSTRUCTION_FILTERS[5][4], default=False
    )
    skip_rectangles: BoolProperty(
        name="矩形", description=_CONSTRUCTION_FILTERS[6][4], default=False
    )
    skip_extrudes: BoolProperty(
        name="拉伸历史", description=_CONSTRUCTION_FILTERS[7][4], default=False
    )
    skip_cuts: BoolProperty(
        name="切割/凹槽", description=_CONSTRUCTION_FILTERS[8][4], default=False
    )
    skip_terrain: BoolProperty(
        name="地形/场地", description=_CONSTRUCTION_FILTERS[9][4], default=False
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        prefs = context.preferences.addons.get(__package__)

        # ── 变换 ────────────────────────────────────────────────────────
        layout.label(text="变换")
        layout.prop(self, "up_axis", text="源文件朝上轴")
        layout.prop(self, "rotation_deg")
        layout.prop(self, "scale")
        layout.separator()
        layout.prop(self, "placement")
        layout.prop(self, "origin_offset")
        layout.separator()

        # ── 质量与外观 ──────────────────────────────────────────────────
        layout.label(text="质量与外观")
        if prefs:
            layout.prop(prefs.preferences, "tol_preset")
            if prefs.preferences.tol_preset == "CUSTOM":
                layout.prop(prefs.preferences, "tol_linear")
                layout.prop(prefs.preferences, "tol_angular")
            layout.prop(prefs.preferences, "tol_relative")
            layout.prop(prefs.preferences, "import_materials")
            layout.prop(prefs.preferences, "shade_smooth")
        layout.separator()

        # ── 结构 ─────────────────────────────────────────────────────────
        layout.label(text="结构")
        if prefs:
            row = layout.row()
            row.active = not self.merge_objects
            row.prop(self, "use_assembly_collections")
        layout.prop(self, "merge_objects")
        layout.separator()

        # ── 清理 ───────────────────────────────────────────────────────────
        header, panel = layout.panel("step_cleanup", default_closed=True)
        header.label(text="清理")
        if panel and prefs:
            panel.prop(prefs.preferences, "cleanup_topology")
            if prefs.preferences.cleanup_topology:
                box = panel.box()
                box.prop(prefs.preferences, "ct_doubles")
                if prefs.preferences.ct_doubles:
                    box.prop(prefs.preferences, "ct_doubles_dist")
                box.prop(prefs.preferences, "ct_dissolve")
                if prefs.preferences.ct_dissolve:
                    box.prop(prefs.preferences, "ct_dissolve_angle")

        # ── 跳过构造几何体 ────────────────────────────────────────────────
        header, panel = layout.panel("step_filters", default_closed=True)
        header.label(text="跳过构造几何体")
        if panel:
            col = panel.column(align=True)
            for prop_name, label, *_ in _CONSTRUCTION_FILTERS:
                col.prop(self, prop_name)

    def invoke(self, context, event):
        prefs = context.preferences.addons.get(__package__)
        if prefs:
            self.up_axis = prefs.preferences.default_up_axis
            self.rotation_deg = prefs.preferences.default_rotation
            self.placement = prefs.preferences.default_placement
            self.origin_offset = prefs.preferences.default_origin_offset
            self.scale = prefs.preferences.default_scale
            self.use_assembly_collections = prefs.preferences.use_assembly_collections

        if self.filepath or self.files:
            return context.window_manager.invoke_props_dialog(self)

        return super().invoke(context, event)

    def execute(self, context):
        if not cascadio_available():
            self.report(
                {"ERROR"},
                "cascadio 不可用。请检查扩展是否正确安装。",
            )
            return {"CANCELLED"}

        # Build the list of absolute paths to import.
        if self.files:
            filepaths = [
                os.path.join(self.directory, f.name)
                for f in self.files
                if f.name
            ]
        elif self.filepath:
            filepaths = [self.filepath]
        else:
            self.report({"ERROR"}, "未选择文件。")
            return {"CANCELLED"}

        skip_prefixes = frozenset(
            p
            for prop_name, _label, _default, prefixes, _tip in _CONSTRUCTION_FILTERS
            if getattr(self, prop_name)
            for p in prefixes
        )

        total = len(filepaths)
        errors = []
        for i, filepath in enumerate(filepaths):
            label = (
                f"[{i + 1}/{total}] {os.path.basename(filepath)}"
                if total > 1
                else ""
            )
            try:
                import_step(
                    filepath,
                    up_axis=self.up_axis,
                    rotation_deg=float(self.rotation_deg),
                    merge_objects=self.merge_objects,
                    skip_prefixes=skip_prefixes,
                    label=label,
                    placement=self.placement,
                    origin_offset=self.origin_offset,
                    use_assembly_collections=self.use_assembly_collections,
                    scale=self.scale,
                )
            except Exception as e:
                traceback.print_exc()
                errors.append(f"{os.path.basename(filepath)}: {e}")

        for err in errors:
            self.report({"ERROR"}, err)

        succeeded = total - len(errors)
        return {"FINISHED"} if succeeded > 0 else {"CANCELLED"}


class STEP_FH_import(bpy.types.FileHandler):
    """Drag-and-drop support for STEP/IGES files onto the 3D viewport."""

    bl_idname = "STEP_FH_import"
    bl_label = "STEP/IGES 文件处理器"
    bl_import_operator = "import_scene.step"
    bl_file_extensions = ".step;.stp;.iges;.igs"

    @classmethod
    def poll_drop(cls, context):
        return context.area and context.area.type == "VIEW_3D"


def _menu_func_import(self, context):
    self.layout.operator(
        ImportSTEPOperator.bl_idname, text="STEP/IGES (.step/.stp/.igs)"
    )


def register():
    bpy.utils.register_class(ImportSTEPOperator)
    bpy.utils.register_class(STEP_FH_import)
    bpy.types.TOPBAR_MT_file_import.append(_menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_func_import)
    bpy.utils.unregister_class(STEP_FH_import)
    bpy.utils.unregister_class(ImportSTEPOperator)
