"""
This file is a part of Blosm addon for Blender.
Copyright (C) 2014-2018 Vladimir Elistratov
prokitektura+support@gmail.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from datetime import datetime
from ..building.manager import BuildingManager


class Logger:
    
    def __init__(self, app, osm):
        self.parseStartTime = datetime.now()
        app.logger = self
        self.app = app
        self.osm = osm
        print("正在解析 OSM 文件 %s..." % app.osmFilepath)
    
    def processStart(self):
        print("解析 OSM 文件所用时间：%s" % (datetime.now() - self.parseStartTime))
        self.processStartTime = datetime.now()
        print("正在处理已解析的 OSM 数据...")

    def processEnd(self):
        self.numBuildings()
        print("处理已解析的 OSM 数据所用时间：%s" % (datetime.now() - self.processStartTime))
    
    def renderStart(self):
        self.renderStartTime = datetime.now()
        print("正在 Blender 中创建网格...")

    def renderEnd(self):
        t = datetime.now()
        print("Blender 中网格创建所用时间：%s" % (t - self.renderStartTime))
        print("总耗时：%s" % (t - self.parseStartTime))
    
    def numBuildings(self):
        app = self.app
        if app.mode is app.twoD or not app.buildings:
            return
        for m in app.managers:
            if isinstance(m, BuildingManager):
                print("建筑数量：%s" % len(m.buildings))