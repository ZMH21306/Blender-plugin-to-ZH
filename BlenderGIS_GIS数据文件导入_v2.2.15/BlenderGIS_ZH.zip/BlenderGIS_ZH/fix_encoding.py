# -*- coding: utf-8 -*-
"""Add UTF-8 encoding declaration to all Python files that are missing it."""
import os
import glob

BASE = os.path.dirname(os.path.abspath(__file__))
SKIP = {'__pycache__'}
LIB_DIRS = ['lib', 'Tyf', 'imageio', 'overpy']

ENCODING_DECL = '# -*- coding: utf-8 -*-\n'

count = 0
for py in glob.glob(os.path.join(BASE, '**', '*.py'), recursive=True):
    # Skip __pycache__
    if '__pycache__' in py:
        continue
    
    rel = os.path.relpath(py, BASE)
    
    # Skip third-party libraries
    parts = rel.replace('\\', '/').split('/')
    if any(d in LIB_DIRS for d in parts):
        continue
    
    with open(py, 'r', encoding='utf-8') as f:
        first_lines = f.read(200)
    
    # Check if already has encoding declaration
    if 'coding' in first_lines.split('\n')[0] or 'coding' in (first_lines.split('\n')[1] if len(first_lines.split('\n')) > 1 else ''):
        continue
    
    # Add encoding declaration
    with open(py, 'r', encoding='utf-8') as f:
        content = f.read()
    
    with open(py, 'w', encoding='utf-8', newline='') as f:
        f.write(ENCODING_DECL + content)
    
    print(f"ADDED: {rel}")
    count += 1

print(f"\nTotal: {count} files updated")
