# -*- coding:utf-8 -*-

# This file is part of BlenderGIS

#  ***** GPL LICENSE BLOCK *****
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#  All rights reserved.
#  ***** GPL LICENSE BLOCK *****

import bpy
import bmesh
import os
import math
from mathutils import Vector
import numpy as np#Ship with Blender since 2.70

import logging
log = logging.getLogger(__name__)

from ..geoscene import GeoScene, georefManagerLayout
from ..prefs import PredefCRS

from ..core.georaster import GeoRaster
from .utils import bpyGeoRaster, exportAsMesh
from .utils import placeObj, adjust3Dview, showTextures, addTexture, getBBOX
from .utils import rasterExtentToMesh, geoRastUVmap, setDisplacer

from ..core import HAS_GDAL
if HAS_GDAL:
	from osgeo import gdal

from ..core import XY as xy
from ..core.errors import OverlapError
from ..core.proj import Reproj

from bpy_extras.io_utils import ImportHelper #helper class defines filename and invoke() function which calls the file selector
from bpy.props import StringProperty, BoolProperty, EnumProperty, IntProperty
from bpy.types import Operator

PKG, SUBPKG = __package__.split('.', maxsplit=1)

class IMPORTGIS_OT_georaster(Operator, ImportHelper):
	"""Import georeferenced raster (need world file)"""
	bl_idname = "importgis.georaster"  # important since its how bpy.ops.importgis.georaster is constructed (allows calling operator from python console or another script)
	#bl_idname rules: must contain one '.' (dot) charactere, no capital letters, no reserved words (like 'import')
	bl_description = '导入带世界文件的地理配准栅格'
	bl_label = "导入地理栅格"
	bl_options = {"UNDO"}

	def listObjects(self, context):
		#Function used to update the objects list (obj_list) used by the dropdown box.
		objs = [] #list containing tuples of each object
		for index, object in enumerate(bpy.context.scene.objects): #iterate over all objects
			if object.type == 'MESH':
				objs.append((str(index), object.name, "对象 " +object.name)) #put each object in a tuple (key, label, tooltip) and add this to the objects list
		return objs

	# ImportHelper class properties
	filter_glob: StringProperty(
			default="*.tif;*.jpg;*.jpeg;*.png;*.bmp",
			options={'HIDDEN'},
			)

	# Raster CRS definition
	def listPredefCRS(self, context):
		return PredefCRS.getEnumItems()
	rastCRS: EnumProperty(
		name = "栅格坐标系",
		description = "选择坐标参考系",
		items = listPredefCRS,
		)
	reprojection: BoolProperty(
			name="指定栅格坐标系",
			description="如果栅格坐标系与场景坐标系不同，请指定",
			default=False )

	# List of operator properties, the attributes will be assigned
	# to the class instance from the operator settings before calling.
	importMode: EnumProperty(
			name="模式",
			description="选择导入模式",
			items=[ ('PLANE', '底图置于新平面', '将栅格纹理放置在新平面网格上'),
			('BKG', '底图作为背景', '将栅格作为背景图像放置'),
			('MESH', '底图映射到网格', '将栅格UV映射到现有网格'),
			('DEM', 'DEM作为置换纹理', '使用DEM栅格作为高度纹理包裹基础网格'),
			('DEM_RAW', 'DEM原始数据构建[慢]', '将DEM导入为像素点云并构建面。不适用于大数据集。')]
			)
	#
	objectsLst: EnumProperty(attr="obj_list", name="对象", description="选择要编辑的对象", items=listObjects)
	#
	#Subdivise (as DEM option)
	def listSubdivisionModes(self, context):
		items = [ ('subsurf', '细分表面', '添加细分表面修改器'), ('none', '无', '不细分')]
		if not self.demOnMesh:
			#mesh subdivision method can not be applyed on an existing mesh
			#this option makes sense only when the mesh is created from scratch
			items.append(('mesh', '网格', '在每个像素处创建顶点'))
		return items

	subdivision: EnumProperty(
			name="细分",
			description="平面细分方式（置换器需要顶点才能工作）",
			items=listSubdivisionModes
			)
	#
	demOnMesh: BoolProperty(
			name="应用到现有网格",
			description="将DEM用作现有网格的置换器",
			default=False
			)
	#
	clip: BoolProperty(
			name="裁剪到工作范围",
			description="使用参考边界框裁剪DEM",
			default=False
			)
	#
	demInterpolation: BoolProperty(
			name="平滑地形",
			description="使用纹理插值平滑结果地形",
			default=True
			)
	#
	fillNodata: BoolProperty(
			name="填充无数据值",
			description="插值现有无数据值以获得可用的置换纹理",
			default=False
			)
	#
	step: IntProperty(name = "步长", default=1, description="像素步长", min=1)

	buildFaces: BoolProperty(name="构建面", default=True, description='构建连接像素点云的四边形面')

	def draw(self, context):
		#Function used by blender to draw the panel.
		layout = self.layout
		layout.prop(self, 'importMode')
		scn = bpy.context.scene
		geoscn = GeoScene(scn)
		#
		if self.importMode == 'PLANE':
			pass
		#
		if self.importMode == 'BKG':
			pass
		#
		if self.importMode == 'MESH':
			if geoscn.isGeoref and len(self.objectsLst) > 0:
				layout.prop(self, 'objectsLst')
			else:
				layout.label(text="没有可UV映射的地理配准网格")
		#
		if self.importMode == 'DEM':
			layout.prop(self, 'demOnMesh')
			if self.demOnMesh:
				if geoscn.isGeoref and len(self.objectsLst) > 0:
					layout.prop(self, 'objectsLst')
					layout.prop(self, 'clip')
				else:
					layout.label(text="没有可应用的地理配准网格")
			layout.prop(self, 'subdivision')
			layout.prop(self, 'demInterpolation')
			if self.subdivision == 'mesh':
				layout.prop(self, 'step')
			layout.prop(self, 'fillNodata')
		#
		if self.importMode == 'DEM_RAW':
			layout.prop(self, 'buildFaces')
			layout.prop(self, 'step')
			layout.prop(self, 'clip')
			if self.clip:
				if geoscn.isGeoref and len(self.objectsLst) > 0:
					layout.prop(self, 'objectsLst')
				else:
					layout.label(text="没有可参考的地理配准网格")
		#
		if geoscn.isPartiallyGeoref:
			layout.prop(self, 'reprojection')
			if self.reprojection:
				self.crsInputLayout(context)
			#
			georefManagerLayout(self, context)
		else:
			self.crsInputLayout(context)

	def crsInputLayout(self, context):
		layout = self.layout
		row = layout.row(align=True)
		split = row.split(factor=0.35, align=True)
		split.label(text='坐标系:')
		split.prop(self, "rastCRS", text='')
		row.operator("bgis.add_predef_crs", text='', icon='ADD')

	@classmethod
	def poll(cls, context):
		return context.mode == 'OBJECT'

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences

		bpy.ops.object.select_all(action='DESELECT')
		#Get scene and some georef data
		scn = bpy.context.scene
		geoscn = GeoScene(scn)
		if geoscn.isBroken:
			self.report({'ERROR'}, "场景地理配准已损坏，请先修复")
			return {'CANCELLED'}

		scale = geoscn.scale #TODO

		if geoscn.isGeoref:
			dx, dy = geoscn.getOriginPrj()
			if self.reprojection:
				rastCRS = self.rastCRS
			else:
				rastCRS = geoscn.crs
		else: #if not geoscn.hasCRS
			rastCRS = self.rastCRS
			try:
				geoscn.crs = rastCRS
			except Exception as e:
				log.error("Cannot set scene crs", exc_info=True)
				self.report({'ERROR'}, "无法设置场景坐标系，请查看日志获取更多信息")
				return {'CANCELLED'}

		#Raster reprojection throught UV mapping
		#build reprojector objects
		if geoscn.crs != rastCRS:
			rprj = True
			rprjToRaster = Reproj(geoscn.crs, rastCRS)
			rprjToScene = Reproj(rastCRS, geoscn.crs)
		else:
			rprj = False
			rprjToRaster = None
			rprjToScene = None

		#Path
		filePath = self.filepath
		name = os.path.basename(filePath)[:-4]

		######################################
		if self.importMode == 'PLANE':#on plane
			#Load raster
			try:
				rast = bpyGeoRaster(filePath)
			except IOError as e:
				log.error("Unable to open raster", exc_info=True)
				self.report({'ERROR'}, "无法打开栅格，请查看日志获取更多信息")
				return {'CANCELLED'}
			#Get or set georef dx, dy
			if not geoscn.isGeoref:
				dx, dy = rast.center.x, rast.center.y
				if rprj:
					dx, dy = rprjToScene.pt(dx, dy)
				geoscn.setOriginPrj(dx, dy)
			#create a new mesh from raster extent
			mesh = rasterExtentToMesh(name, rast, dx, dy, reproj=rprjToScene)
			#place obj
			obj = placeObj(mesh, name)
			#UV mapping
			uvTxtLayer = mesh.uv_layers.new(name='rastUVmap')# Add UV map texture layer
			geoRastUVmap(obj, uvTxtLayer, rast, dx, dy, reproj=rprjToRaster)
			# Create material
			mat = bpy.data.materials.new('rastMat')
			# Add material to current object
			obj.data.materials.append(mat)
			# Add texture to material
			addTexture(mat, rast.bpyImg, uvTxtLayer, name='rastText')

		######################################
		if self.importMode == 'BKG':#background
			if rprj:
				#TODO, do gdal true reproj
				self.report({'ERROR'}, "后台模式下无法进行栅格重投影")
				return {'CANCELLED'}
			#Load raster
			try:
				rast = bpyGeoRaster(filePath)
			except IOError as e:
				log.error("Unable to open raster", exc_info=True)
				self.report({'ERROR'}, "无法打开栅格，请查看日志获取更多信息")
				return {'CANCELLED'}
			#Check pixel size and rotation
			if rast.rotation.xy != [0,0]:
				self.report({'ERROR'}, "后台图像模式下无法应用旋转")
				return {'CANCELLED'}
			if abs(round(rast.pxSize.x, 3)) != abs(round(rast.pxSize.y, 3)):
				self.report({'ERROR'}, "背景图像在X和Y轴方向上需要相等的像素大小（地图单位）")
				return {'CANCELLED'}
			#
			trueSizeX = rast.geoSize.x
			trueSizeY = rast.geoSize.y
			ratio = rast.size.x / rast.size.y
			if geoscn.isGeoref:
				offx, offy = rast.center.x - dx, rast.center.y - dy
			else:
				dx, dy = rast.center.x, rast.center.y
				geoscn.setOriginPrj(dx, dy)
				offx, offy = 0, 0

			bkg = bpy.data.objects.new(self.name, None) #None will create an empty
			bkg.empty_display_type = 'IMAGE'
			bkg.empty_image_depth = 'BACK'
			bkg.data = rast.bpyImg
			scn.collection.objects.link(bkg)

			bkg.empty_display_size = 1 #a size of 1 means image width=1bu
			bkg.scale = (trueSizeX, trueSizeY*ratio, 1)
			bkg.location = (offx, offy, 0)

			bpy.context.view_layer.objects.active = bkg
			bkg.select_set(True)

			if prefs.adjust3Dview:
				adjust3Dview(context, rast.bbox)

		######################################
		if self.importMode == 'MESH':
			if not geoscn.isGeoref or len(self.objectsLst) == 0:
				self.report({'ERROR'}, "没有可应用的地理配准网格")
				return {'CANCELLED'}
			# Get choosen object
			obj = scn.objects[int(self.objectsLst)]
			# Select and active this obj
			obj.select_set(True)
			context.view_layer.objects.active = obj
			# Compute projeted bbox (in geographic coordinates system)
			subBox = getBBOX.fromObj(obj).toGeo(geoscn)
			if rprj:
				subBox = rprjToRaster.bbox(subBox)
			#Load raster
			try:
				rast = bpyGeoRaster(filePath, subBoxGeo=subBox)
			except IOError as e:
				log.error("Unable to open raster", exc_info=True)
				self.report({'ERROR'}, "无法打开栅格，请查看日志获取更多信息")
				return {'CANCELLED'}
			except OverlapError:
				self.report({'ERROR'}, "数据不重叠")
				return {'CANCELLED'}
			# Add UV map texture layer
			mesh = obj.data
			uvTxtLayer = mesh.uv_layers.new(name='rastUVmap')
			uvTxtLayer.active = True
			# UV mapping
			geoRastUVmap(obj, uvTxtLayer, rast, dx, dy, reproj=rprjToRaster)
			# Add material and texture
			mat = bpy.data.materials.new('rastMat')
			obj.data.materials.append(mat)
			addTexture(mat, rast.bpyImg, uvTxtLayer, name='rastText')

		######################################
		if self.importMode == 'DEM':

			# Get reference plane
			if self.demOnMesh:
				if not geoscn.isGeoref or len(self.objectsLst) == 0:
					self.report({'ERROR'}, "没有可应用的地理配准网格")
					return {'CANCELLED'}
				# Get choosen object
				obj = scn.objects[int(self.objectsLst)]
				mesh = obj.data
				# Select and active this obj
				obj.select_set(True)
				context.view_layer.objects.active = obj
				# Compute projeted bbox (in geographic coordinates system)
				subBox = getBBOX.fromObj(obj).toGeo(geoscn)
				if rprj:
					subBox = rprjToRaster.bbox(subBox)
			else:
				subBox = None

			# Load raster
			try:
				grid = bpyGeoRaster(filePath, subBoxGeo=subBox, clip=self.clip, fillNodata=self.fillNodata, useGDAL=HAS_GDAL, raw=True)
			except IOError as e:
				log.error("Unable to open raster", exc_info=True)
				self.report({'ERROR'}, "无法打开栅格，请查看日志获取更多信息")
				return {'CANCELLED'}
			except OverlapError:
				self.report({'ERROR'}, "数据不重叠")
				return {'CANCELLED'}

			# If needed, create a new plane object from raster extent
			if not self.demOnMesh:
				if not geoscn.isGeoref:
					dx, dy = grid.center.x, grid.center.y
					if rprj:
						dx, dy = rprjToScene.pt(dx, dy)
					geoscn.setOriginPrj(dx, dy)
				if self.subdivision == 'mesh':#Mesh cut
					mesh = exportAsMesh(grid, dx, dy, self.step, reproj=rprjToScene, flat=True)
				else:
					mesh = rasterExtentToMesh(name, grid, dx, dy, pxLoc='CENTER', reproj=rprjToScene) #use pixel center to avoid displacement glitch
				obj = placeObj(mesh, name)
				subBox = getBBOX.fromObj(obj).toGeo(geoscn)

			# Add UV map texture layer
			previousUVmapIdx = mesh.uv_layers.active_index
			uvTxtLayer = mesh.uv_layers.new(name='demUVmap')
			#UV mapping
			geoRastUVmap(obj, uvTxtLayer, grid, dx, dy, reproj=rprjToRaster)
			#Restore previous uv map
			if previousUVmapIdx != -1:
				mesh.uv_layers.active_index = previousUVmapIdx
			#Make subdivision
			if self.subdivision == 'subsurf':#Add subsurf modifier
				if not 'SUBSURF' in [mod.type for mod in obj.modifiers]:
					subsurf = obj.modifiers.new('DEM', type='SUBSURF')
					subsurf.subdivision_type = 'SIMPLE'
					subsurf.levels = 6
					subsurf.render_levels = 6
			#Set displacer
			dsp = setDisplacer(obj, grid, uvTxtLayer, interpolation=self.demInterpolation)

		######################################
		if self.importMode == 'DEM_RAW':

			# Get reference plane
			subBox = None
			if self.clip:
				if not geoscn.isGeoref or len(self.objectsLst) == 0:
					self.report({'ERROR'}, "没有工作范围")
					return {'CANCELLED'}
				# Get choosen object
				obj = scn.objects[int(self.objectsLst)]
				subBox = getBBOX.fromObj(obj).toGeo(geoscn)
				if rprj:
					subBox = rprjToRaster.bbox(subBox)

			# Load raster
			try:
				grid = GeoRaster(filePath, subBoxGeo=subBox, useGDAL=HAS_GDAL)
			except IOError as e:
				log.error("Unable to open raster", exc_info=True)
				self.report({'ERROR'}, "无法打开栅格，请查看日志获取更多信息")
				return {'CANCELLED'}
			except OverlapError:
				self.report({'ERROR'}, "数据不重叠")
				return {'CANCELLED'}

			if not geoscn.isGeoref:
				dx, dy = grid.center.x, grid.center.y
				if rprj:
					dx, dy = rprjToScene.pt(dx, dy)
				geoscn.setOriginPrj(dx, dy)
			mesh = exportAsMesh(grid, dx, dy, self.step, reproj=rprjToScene, subset=self.clip, flat=False, buildFaces=self.buildFaces)
			obj = placeObj(mesh, name)
			#grid.unload()

		######################################

		#Flag if a new object as been created...
		if self.importMode == 'PLANE' or (self.importMode == 'DEM' and not self.demOnMesh) or self.importMode == 'DEM_RAW':
			newObjCreated = True
		else:
			newObjCreated = False

		#...if so, maybee we need to adjust 3d view settings to it
		if newObjCreated and prefs.adjust3Dview:
			bb = getBBOX.fromObj(obj)
			adjust3Dview(context, bb)

		#Force view mode with textures
		if prefs.forceTexturedSolid:
			showTextures(context)


		return {'FINISHED'}


def register():
	try:
		bpy.utils.register_class(IMPORTGIS_OT_georaster)
	except ValueError as e:
		log.warning('{} is already registered, now unregister and retry... '.format(IMPORTGIS_OT_georaster))
		unregister()
		bpy.utils.register_class(IMPORTGIS_OT_georaster)

def unregister():
	bpy.utils.unregister_class(IMPORTGIS_OT_georaster)
