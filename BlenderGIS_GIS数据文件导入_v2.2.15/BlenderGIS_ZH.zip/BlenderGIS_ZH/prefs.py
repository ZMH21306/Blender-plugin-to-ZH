# -*- coding: utf-8 -*-
import json
import logging
log = logging.getLogger(__name__)
import sys, os

import bpy
from bpy.props import StringProperty, IntProperty, FloatProperty, BoolProperty, EnumProperty, FloatVectorProperty
from bpy.types import Operator, Panel, AddonPreferences
import addon_utils

from . import bl_info
from .core.proj.reproj import MapTilerCoordinates
from .core.proj.srs import SRS
from .core.checkdeps import HAS_GDAL, HAS_PYPROJ, HAS_PIL, HAS_IMGIO
from .core import settings

PKG = __package__

def getAppData():
	home = os.path.expanduser('~')
	loc = os.path.join(home, '.bgis')
	if not os.path.exists(loc):
		os.mkdir(loc)
	return loc

APP_DATA = getAppData()

'''
Default Enum properties contents (list of tuple (value, label, tootip))
Theses properties are automatically filled from a serialized json string stored in a StringProperty
This is workaround to have an editable EnumProperty (ie the user can add, remove or edit an entry)
because the Blender Python API does not provides built in functions for these tasks.
To edit the content of these enum, we just need to write new operators which will simply update the json string
As the json backend is stored in addon preferences, the property will be saved and restored for the next blender session
'''


DEFAULT_CRS = [
	('EPSG:3857', 'Web 墨卡托投影', '全球投影，变形较大，不适合精确建模'),
	('EPSG:4326', 'WGS84 经纬度', '以度为单位的经纬度，不要用作场景坐标系（仅用于重投影任务）')
]


DEFAULT_DEM_SERVER = [
	("https://portal.opentopography.org/API/globaldem?demtype=SRTMGL1&west={W}&east={E}&south={S}&north={N}&outputFormat=GTiff&API_Key={API_KEY}", 'OpenTopography SRTM 30m', 'OpenTopography.org SRTM 30m 全球高程数据服务'),
	("https://portal.opentopography.org/API/globaldem?demtype=SRTMGL3&west={W}&east={E}&south={S}&north={N}&outputFormat=GTiff&API_Key={API_KEY}", 'OpenTopography SRTM 90m', 'OpenTopography.org SRTM 90m 全球高程数据服务'),
	("http://www.gmrt.org/services/GridServer?west={W}&east={E}&south={S}&north={N}&layer=topo&format=geotiff&resolution=high", 'Marine-geo.org GMRT', 'Marine-geo.org GMRT 全球高程数据服务（陆地 ASTER 和水深）')
]

DEFAULT_OVERPASS_SERVER =  [
	("https://lz4.overpass-api.de/api/interpreter", 'overpass-api.de', 'Overpass API 主实例'),
	("http://overpass.openstreetmap.fr/api/interpreter", 'overpass.openstreetmap.fr', '法国 Overpass API 实例'),
	("https://overpass.kumi.systems/api/interpreter", 'overpass.kumi.systems', 'Kumi Systems Overpass 实例')
]

# OSM tag translation dict
OSM_TAG_LABELS = {
	'building': '建筑',
	'highway': '道路',
	'landuse': '土地利用',
	'leisure': '休闲',
	'natural': '自然',
	'railway': '铁路',
	'waterway': '水道',
	'aeroway': '航空设施',
	'amenity': '公共设施',
	'boundary': '边界',
	'craft': '手工业',
	'emergency': '应急设施',
	'healthcare': '医疗',
	'historic': '历史遗迹',
	'man_made': '人造物',
	'military': '军事',
	'office': '办公',
	'place': '地点',
	'power': '电力设施',
	'public_transport': '公共交通',
	'shop': '商店',
	'sport': '运动',
	'tourism': '旅游',
	'water': '水体',
}

#default filter tags for OSM import
DEFAULT_OSM_TAGS = [
	'building',
	'highway',
	'landuse',
	'leisure',
	'natural',
	'railway',
	'waterway'
]



class BGIS_OT_pref_show(Operator):

	bl_idname = "bgis.pref_show"
	bl_description = '显示 BlenderGIS 插件偏好设置'
	bl_label = "偏好设置"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		addon_utils.modules_refresh()
		context.preferences.active_section = 'ADDONS'
		bpy.data.window_managers["WinMan"].addon_search = bl_info['name']
		#bpy.ops.wm.addon_expand(module=PKG)
		mod = addon_utils.addons_fake_modules.get(PKG)
		mod.bl_info['show_expanded'] = True
		bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
		return {'FINISHED'}



class BGIS_PREFS(AddonPreferences):

	bl_idname = PKG

	################
	#Predefined Spatial Ref. Systems

	def listPredefCRS(self, context):
		return [tuple(elem) for elem in json.loads(self.predefCrsJson)]

	#store crs preset as json string into addon preferences
	predefCrsJson: StringProperty(default=json.dumps(DEFAULT_CRS))

	predefCrs: EnumProperty(
		name = "预定义坐标系",
		description = "选择预定义的坐标参考系",
		#default = 1, #possible only since Blender 2.90
		items = listPredefCRS
		)

	################
	#proj engine

	def getProjEngineItems(self, context):
		items = [ ('AUTO', '自动检测', '自动选择最佳的重投影库') ]
		if HAS_GDAL:
			items.append( ('GDAL', 'GDAL', '强制使用 GDAL 作为重投影引擎') )
		if HAS_PYPROJ:
			items.append( ('PYPROJ', 'pyProj', '强制使用 pyProj 作为重投影引擎') )
		#if EPSGIO.ping(): #too slow
		#	items.append( ('EPSGIO', 'epsg.io', '') )
		items.append( ('EPSGIO', 'epsg.io / MapTilerCoords', '强制使用 epsg.io 作为重投影引擎') )
		items.append( ('BUILTIN', '内置', '强制使用内置 Python 函数进行重投影') )
		return items

	def updateProjEngine(self, context):
		settings.proj_engine = self.projEngine

	projEngine: EnumProperty(
		name = "投影引擎",
		description = "选择投影引擎",
		items = getProjEngineItems,
		update = updateProjEngine
		)

	################
	#img engine

	def getImgEngineItems(self, context):
		items = [ ('AUTO', '自动检测', '自动选择最佳图像处理库') ]
		if HAS_GDAL:
			items.append( ('GDAL', 'GDAL', '强制使用 GDAL 作为图像处理引擎') )
		if HAS_IMGIO:
			items.append( ('IMGIO', 'ImageIO', '强制使用 ImageIO 作为图像处理引擎') )
		if HAS_PIL:
			items.append( ('PIL', 'PIL', '强制使用 PIL 作为图像处理引擎') )
		return items

	def updateImgEngine(self, context):
		settings.img_engine = self.imgEngine

	imgEngine: EnumProperty(
		name = "图像处理引擎",
		description = "选择图像处理引擎",
		items = getImgEngineItems,
		update = updateImgEngine
		)

	################
	#OSM

	osmTagsJson: StringProperty(default=json.dumps(DEFAULT_OSM_TAGS)) #just a serialized list of tags

	def listOsmTags(self, context):
		prefs = context.preferences.addons[PKG].preferences
		tags = json.loads(prefs.osmTagsJson)
		#put each item in a tuple (key, label, tooltip) - translate labels
		return [ (tag, OSM_TAG_LABELS.get(tag, tag), tag) for tag in tags]

	osmTags: EnumProperty(
		name = "OSM 标签",
		description = "已注册的 OSM 标签列表",
		items = listOsmTags
		)

	################
	#Basemaps

	def getCacheFolder5x(self, v, isSet):
		return bpy.path.abspath(v)

	def getCacheFolder(self):
		return bpy.path.abspath(self.get("cacheFolder", ''))

	def setCacheFolder5x(self, newVal, currentVal, isSet):
		if os.access(newVal, os.X_OK | os.W_OK):
			return newVal
		else:
			log.error("The selected cache folder has no write access")

	def setCacheFolder(self, value):
		if os.access(value, os.X_OK | os.W_OK):
			self["cacheFolder"] = value
		else:
			self["cacheFolder"] = "所选文件夹没有写入权限"

	if bpy.app.version[0] >= 5 :
		cacheFolder: StringProperty(
			name = "缓存文件夹",
			default = APP_DATA, #Does not works !?
			description = "定义用于存储 Geopackage SQLite 数据库的文件夹",
			subtype = 'DIR_PATH',
			get_transform = getCacheFolder5x,
			set_transform = setCacheFolder5x
			)
	else:
		cacheFolder: StringProperty(
			name = "缓存文件夹",
			default = APP_DATA, #Does not works !?
			description = "定义用于存储 Geopackage SQLite 数据库的文件夹",
			subtype = 'DIR_PATH',
			get = getCacheFolder,
			set = setCacheFolder
			)


	synchOrj: BoolProperty(
		name="同步经纬度",
		description='保持地理原点与坐标系原点同步，使用远程重投影服务时可能较慢',
		default=True)

	zoomToMouse: BoolProperty(name="缩放至鼠标位置", description='向鼠标指针位置缩放', default=True)

	lockOrigin: BoolProperty(name="锁定原点", description='平移地图时不移动场景原点', default=False)
	lockObj: BoolProperty(name="锁定物体", description='移动地图原点时保持物体地理定位', default=True)

	resamplAlg: EnumProperty(
		name = "重采样方法",
		description = "选择用于重投影的 GDAL 重采样方法",
		items = [ ('NN', '最近邻', ''), ('BL', '双线性', ''), ('CB', '三次', ''), ('CBS', '三次样条', ''), ('LCZ', 'Lanczos', '') ]
		)

	################
	#Network

	def listOverpassServer(self, context):
		return [tuple(entry) for entry in json.loads(self.overpassServerJson)]

	#store crs preset as json string into addon preferences
	overpassServerJson: StringProperty(default=json.dumps(DEFAULT_OVERPASS_SERVER))

	overpassServer: EnumProperty(
		name = "Overpass 服务器",
		description = "选择 Overpass 服务器",
		#default = 0,
		items = listOverpassServer
		)

	def listDemServer(self, context):
		return [tuple(entry) for entry in json.loads(self.demServerJson)]

	#store crs preset as json string into addon preferences
	demServerJson: StringProperty(default=json.dumps(DEFAULT_DEM_SERVER))

	demServer: EnumProperty(
		name = "高程服务器",
		description = "选择提供数字高程模型数据源的服务器",
		#default = 0,
		items = listDemServer
		)

	opentopography_api_key: StringProperty(
		name = "",
		description="您需要从 opentopography 网站注册并申请密钥"
	)

	def updateMapTilerApiKey(self, context):
		settings.maptiler_api_key = self.maptiler_api_key

	maptiler_api_key: StringProperty(
		name = "",
		description = "MapTiler坐标API的密钥（EPSG.io迁移所需）",
		update = updateMapTilerApiKey
	)

	################
	#IO options
	mergeDoubles: BoolProperty(
		name = "合并重复顶点",
		description = '导入矢量数据时合并要素间的共享顶点',
		default = False)
	adjust3Dview: BoolProperty(
		name = "调整3D视图",
		description = "根据新导入物体的尺寸更新3D视图网格大小和裁剪距离",
		default = True)
	forceTexturedSolid: BoolProperty(
		name = "强制纹理实体着色",
		description = "更新着色模式以显示栅格纹理",
		default = True)

	################
	#System
	def updateLogLevel(self, context):
		logger = logging.getLogger(PKG)
		logger.setLevel(logging.getLevelName(self.logLevel))

	logLevel: EnumProperty(
		name = "日志级别",
		description = "选择日志级别",
		items = [('DEBUG', '调试', ''), ('INFO', '信息', ''), ('WARNING', '警告', ''), ('ERROR', '错误', ''), ('CRITICAL', '严重', '')],
		update = updateLogLevel,
		default = 'DEBUG'
		)

	################
	def draw(self, context):
		layout = self.layout

		#SRS
		box = layout.box()
		box.label(text='空间参考系')
		row = box.row().split(factor=0.5)
		row.prop(self, "predefCrs", text='')
		row.operator("bgis.add_predef_crs", icon='ADD')
		row.operator("bgis.edit_predef_crs", icon='PREFERENCES')
		row.operator("bgis.rmv_predef_crs", icon='REMOVE')
		row.operator("bgis.reset_predef_crs", icon='PLAY_REVERSE')

		#Basemaps
		box = layout.box()
		box.label(text='底图')
		box.prop(self, "cacheFolder")
		row = box.row()
		row.prop(self, "zoomToMouse")
		row.prop(self, "lockObj")
		row.prop(self, "lockOrigin")
		row.prop(self, "synchOrj")
		row = box.row()
		row.prop(self, "resamplAlg")

		#IO
		box = layout.box()
		box.label(text='导入/导出')
		row = box.row().split(factor=0.5)
		split = row.split(factor=0.9, align=True)
		split.prop(self, "osmTags")
		split.operator("wm.url_open", icon='INFO').url = "http://wiki.openstreetmap.org/wiki/Map_Features"
		row.operator("bgis.add_osm_tag", icon='ADD')
		row.operator("bgis.edit_osm_tag", icon='PREFERENCES')
		row.operator("bgis.rmv_osm_tag", icon='REMOVE')
		row.operator("bgis.reset_osm_tags", icon='PLAY_REVERSE')
		row = box.row()
		row.prop(self, "mergeDoubles")
		row.prop(self, "adjust3Dview")
		row.prop(self, "forceTexturedSolid")

		#Network
		box = layout.box()
		box.label(text='远程数据源')
		row = box.row().split(factor=0.5)
		row.prop(self, "overpassServer")
		row.operator("bgis.add_overpass_server", icon='ADD')
		row.operator("bgis.edit_overpass_server", icon='PREFERENCES')
		row.operator("bgis.rmv_overpass_server", icon='REMOVE')
		row.operator("bgis.reset_overpass_server", icon='PLAY_REVERSE')
		row = box.row().split(factor=0.5)
		row.prop(self, "demServer")
		row.operator("bgis.add_dem_server", icon='ADD')
		row.operator("bgis.edit_dem_server", icon='PREFERENCES')
		row.operator("bgis.rmv_dem_server", icon='REMOVE')
		row.operator("bgis.reset_dem_server", icon='PLAY_REVERSE')

		row = box.row().split(factor=0.2)
		row.label(text="Opentopography API 密钥")
		row.prop(self, "opentopography_api_key")

		row = box.row().split(factor=0.2)
		row.label(text="MapTiler API 密钥")
		row.prop(self, "maptiler_api_key")

		#System
		box = layout.box()
		box.label(text='系统')
		box.prop(self, "projEngine")
		box.prop(self, "imgEngine")
		box.prop(self, "logLevel")

#######################

class PredefCRS():

	'''
	Collection of utility methods (callable at class level) to deal with predefined CRS dictionary
	Can be used by others operators that need to fill their own crs enum
	'''

	@staticmethod
	def getData():
		'''Load the json string'''
		prefs = bpy.context.preferences.addons[PKG].preferences
		return json.loads(prefs.predefCrsJson)

	@classmethod
	def getName(cls, key):
		'''Return the convenient name of a given srid or None if this crs does not exist in the list'''
		data = cls.getData()
		try:
			return [entry[1] for entry in data if entry[0] == key][0]
		except IndexError:
			return None

	@classmethod
	def getEnumItems(cls):
		'''Return a list of predefined crs usable to fill a bpy EnumProperty'''
		return [tuple(entry) for entry in cls.getData()]


#################
# Collection of operators to manage predefined CRS

class BGIS_OT_add_predef_crs(Operator):
	bl_idname = "bgis.add_predef_crs"
	bl_description = '添加预定义坐标系'
	bl_label = "添加"
	bl_options = {'INTERNAL'}

	crs: StringProperty(name = "定义",  description = "指定此坐标系的 EPSG 代码或 Proj4 字符串定义")
	name: StringProperty(name = "描述", description = "为此坐标系选择一个便捷名称")
	desc: StringProperty(name = "描述", description = "添加关于此坐标系的描述或注释")

	def check(self, context):
		return True

	def search(self, context):

		apiKey = settings.maptiler_api_key

		if not apiKey:
			#self.report({'ERROR'}, "MapTiler API key is required. Please set it in the preferences.") #report is not available outsite of the execute function
			log.error("No Maptiler API key")
			return

		mtc = MapTilerCoordinates(apiKey=apiKey)
		results = mtc.search(self.query)
		self.results = json.dumps(results)
		if results:
			self.crs = 'EPSG:' + str(results[0]['id']['code'])
			self.name = results[0]['name']

	def updEnum(self, context):
		crsItems = []
		if self.results != '':
			for result in json.loads(self.results):
				srid = 'EPSG:' + str(result['id']['code'])
				crsItems.append( (str(result['id']['code']), result['name'], srid) )
		return crsItems

	def fill(self, context):
		if self.results != '':
			crs = [crs for crs in json.loads(self.results) if str(crs['id']['code']) == self.crsEnum][0]
			self.crs = 'EPSG:' + str(crs['id']['code'])
			self.desc = crs['name']

	query: StringProperty(name='查询', description='按回车键执行搜索', update=search)

	results: StringProperty()

	crsEnum: EnumProperty(name='结果', description='选择所需的坐标系', items=updEnum, update=fill)

	search: BoolProperty(name='搜索', description='在 EPSG 数据库中搜索坐标系', default=False)

	save: BoolProperty(name='保存到插件偏好设置',  description='添加后保存 Blender 用户设置', default=False)

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self)#, width=300)

	def draw(self, context):
		layout = self.layout
		layout.prop(self, 'search')
		if self.search:
			prefs = context.preferences.addons[PKG].preferences
			if not prefs.maptiler_api_key:
				layout.label(text="搜索需要 MapTiler API 密钥", icon_value=3)
				layout.prop(prefs, "maptiler_api_key", text='API 密钥')
			else:
				layout.prop(self, 'query')
				layout.prop(self, 'crsEnum')
			layout.separator()
		layout.prop(self, 'crs')
		layout.prop(self, 'name')
		layout.prop(self, 'desc')
		#layout.prop(self, 'save') #sincce Blender2.8 prefs are autosaved

	def execute(self, context):
		if not SRS.validate(self.crs):
			self.report({'ERROR'}, '无效的坐标系')
		if self.crs.isdigit():
			self.crs = 'EPSG:' + self.crs
		#append the new crs def to json string
		prefs = context.preferences.addons[PKG].preferences
		data = json.loads(prefs.predefCrsJson)
		data.append((self.crs, self.name, self.desc))
		prefs.predefCrsJson = json.dumps(data)
		#change enum index to new added crs and redraw
		#prefs.predefCrs = self.crs
		context.area.tag_redraw()
		#end
		if self.save:
			bpy.ops.wm.save_userpref()
		return {'FINISHED'}

class BGIS_OT_rmv_predef_crs(Operator):

	bl_idname = "bgis.rmv_predef_crs"
	bl_description = '移除预定义坐标系'
	bl_label = "移除"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.predefCrs
		if key != '':
			data = json.loads(prefs.predefCrsJson)
			data = [e for e in data if e[0] != key]
			prefs.predefCrsJson = json.dumps(data)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_reset_predef_crs(Operator):

	bl_idname = "bgis.reset_predef_crs"
	bl_description = '重置预定义坐标系'
	bl_label = "重置"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		prefs.predefCrsJson = json.dumps(DEFAULT_CRS)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_edit_predef_crs(Operator):

	bl_idname = "bgis.edit_predef_crs"
	bl_description = '编辑预定义坐标系'
	bl_label = "编辑"
	bl_options = {'INTERNAL'}

	crs: StringProperty(name = "EPSG 代码或 Proj4 字符串",  description = "指定此坐标系的 EPSG 代码或 Proj4 字符串定义")
	name: StringProperty(name = "描述", description = "为此坐标系选择一个便捷名称")
	desc: StringProperty(name = "名称", description = "添加关于此坐标系的描述或注释")

	def invoke(self, context, event):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.predefCrs
		if key == '':
			return {'CANCELLED'}
		data = json.loads(prefs.predefCrsJson)
		entry = [entry for entry in data if entry[0] == key][0]
		self.crs, self.name, self.desc = entry
		return context.window_manager.invoke_props_dialog(self)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.predefCrs
		data = json.loads(prefs.predefCrsJson)

		if SRS.validate(self.crs):
			data = [entry for entry in data if entry[0] != key] #deleting
			data.append((self.crs, self.name, self.desc))
			prefs.predefCrsJson = json.dumps(data)
			context.area.tag_redraw()
		else:
			self.report({'ERROR'}, '无效的坐标系')

		return {'FINISHED'}


#################
# Collection of operators to manage predefinates OSM Tags

class BGIS_OT_add_osm_tag(Operator):
	bl_idname = "bgis.add_osm_tag"
	bl_description = '添加新的预定义 OSM 过滤标签'
	bl_label = "添加"
	bl_options = {'INTERNAL'}

	tag: StringProperty(name = "标签",  description = "指定标签（例如：'building', 'landuse=forest' ...）")

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self)#, width=300)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		tags = json.loads(prefs.osmTagsJson)
		tags.append(self.tag)
		prefs.osmTagsJson = json.dumps(tags)
		prefs.osmTags = self.tag #update current idx
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_rmv_osm_tag(Operator):

	bl_idname = "bgis.rmv_osm_tag"
	bl_description = '移除预定义 OSM 过滤标签'
	bl_label = "移除"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		tag = prefs.osmTags
		if tag != '':
			tags = json.loads(prefs.osmTagsJson)
			del tags[tags.index(tag)]
			prefs.osmTagsJson = json.dumps(tags)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_reset_osm_tags(Operator):

	bl_idname = "bgis.reset_osm_tags"
	bl_description = '重置预定义 OSM 过滤标签'
	bl_label = "重置"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		prefs.osmTagsJson = json.dumps(DEFAULT_OSM_TAGS)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_edit_osm_tag(Operator):

	bl_idname = "bgis.edit_osm_tag"
	bl_description = '编辑预定义 OSM 过滤标签'
	bl_label = "编辑"
	bl_options = {'INTERNAL'}

	tag: StringProperty(name = "标签",  description = "指定标签（例如：'building', 'landuse=forest' ...）")

	def invoke(self, context, event):
		prefs = context.preferences.addons[PKG].preferences
		self.tag = prefs.osmTags
		if self.tag == '':
			return {'CANCELLED'}
		return context.window_manager.invoke_props_dialog(self)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		tag = prefs.osmTags
		tags = json.loads(prefs.osmTagsJson)
		del tags[tags.index(tag)]
		tags.append(self.tag)
		prefs.osmTagsJson = json.dumps(tags)
		prefs.osmTags = self.tag #update current idx
		context.area.tag_redraw()
		return {'FINISHED'}

#################
# Collection of operators to manage DEM server urls

class BGIS_OT_add_dem_server(Operator):
	bl_idname = "bgis.add_dem_server"
	bl_description = '添加新的地形 Web 服务'
	bl_label = "添加"
	bl_options = {'INTERNAL'}

	url: StringProperty(name = "URL 模板",  description = "定义 URL 模板字符串。边界框变量为 {W}、{E}、{S} 和 {N}")
	name: StringProperty(name = "描述", description = "为此服务器选择一个合适的名称")
	desc: StringProperty(name = "描述", description = "添加关于此远程数据源的描述或注释")

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self)#, width=300)

	def execute(self, context):
		templates = ['{W}', '{E}', '{S}', '{N}']
		if all([t in self.url for t in templates]):
			prefs = context.preferences.addons[PKG].preferences
			data = json.loads(prefs.demServerJson)
			data.append( (self.url, self.name, self.desc) )
			prefs.demServerJson = json.dumps(data)
			context.area.tag_redraw()
		else:
			self.report({'ERROR'}, '无效的 URL')
		return {'FINISHED'}

class BGIS_OT_rmv_dem_server(Operator):

	bl_idname = "bgis.rmv_dem_server"
	bl_description = '移除指定的地形 Web 服务'
	bl_label = "移除"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.demServer
		if key != '':
			data = json.loads(prefs.demServerJson)
			data = [e for e in data if e[0] != key]
			prefs.demServerJson = json.dumps(data)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_reset_dem_server(Operator):

	bl_idname = "bgis.reset_dem_server"
	bl_description = '重置为默认地形 Web 服务器'
	bl_label = "重置"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		prefs.demServerJson = json.dumps(DEFAULT_DEM_SERVER)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_edit_dem_server(Operator):

	bl_idname = "bgis.edit_dem_server"
	bl_description = '编辑地形 Web 服务器'
	bl_label = "编辑"
	bl_options = {'INTERNAL'}

	url: StringProperty(name = "URL 模板",  description = "定义 URL 模板字符串。边界框变量为 {W}、{E}、{S} 和 {N}")
	name: StringProperty(name = "描述", description = "为此服务器选择一个合适的名称")
	desc: StringProperty(name = "描述", description = "添加关于此远程数据源的描述或注释")

	def invoke(self, context, event):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.demServer
		if key == '':
			return {'CANCELLED'}
		data = json.loads(prefs.demServerJson)
		entry = [entry for entry in data if entry[0] == key][0]
		self.url, self.name, self.desc = entry
		return context.window_manager.invoke_props_dialog(self)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.demServer
		data = json.loads(prefs.demServerJson)
		templates = ['{W}', '{E}', '{S}', '{N}']
		if all([t in self.url for t in templates]):
			data = [entry for entry in data if entry[0] != key] #deleting
			data.append((self.url, self.name, self.desc))
			prefs.demServerJson = json.dumps(data)
			context.area.tag_redraw()
		else:
			self.report({'ERROR'}, '无效的 URL')
		return {'FINISHED'}

#################

class EditEnum():
	'''
	Helper to deal with an enum property that use a serialized json backend
	Can be used by others operators to edit and EnumProperty
	WORK IN PROGRESS
	'''

	def __init__(self, enumName):
		self.prefs = bpy.context.preferences.addons[PKG].preferences
		self.enumName = enumName
		self.jsonName = enumName + 'Json'

	def getData(self):
		'''Load the json string'''
		data = json.loads(getattr(self.prefs, self.jsonName))
		return [tuple(entry) for entry in data]

	def append(self, value, label, tooltip, check=lambda x: True):
		if not check(value):
			return
		data = self.getData()
		data.append((value, label, tooltip))
		setattr(self.prefs, self.jsonName, json.dumps(data))

	def remove(self, key):
		if key != '':
			data = self.getData()
			data = [e for e in data if e[0] != key]
			setattr(self.prefs, self.jsonName, json.dumps(data))

	def edit(self, key, value, label, tooltip):
		self.remove(key)
		self.append(value, label, tooltip)

	def reset(self):
		setattr(self.prefs, self.jsonName, json.dumps(DEFAULT_OVERPASS_SERVER))

#################
# Collection of operators to manage Overpass server urls

class BGIS_OT_add_overpass_server(Operator):
	bl_idname = "bgis.add_overpass_server"
	bl_description = '添加新的 OSM Overpass 服务器 URL'
	bl_label = "添加"
	bl_options = {'INTERNAL'}

	url: StringProperty(name = "URL 模板",  description = "定义Overpass服务器的URL端点")
	name: StringProperty(name = "描述", description = "为此服务器选择一个合适的名称")
	desc: StringProperty(name = "描述", description = "添加关于此远程服务器的描述或注释")

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self)#, width=300)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		data = json.loads(prefs.overpassServerJson)
		data.append( (self.url, self.name, self.desc) )
		prefs.overpassServerJson = json.dumps(data)
		#EditEnum('overpassServer').append(self.url, self.name, self.desc, check=lambda url: url.startswith('http'))
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_rmv_overpass_server(Operator):

	bl_idname = "bgis.rmv_overpass_server"
	bl_description = '移除指定的 Overpass 服务器'
	bl_label = "移除"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.overpassServer
		if key != '':
			data = json.loads(prefs.overpassServerJson)
			data = [e for e in data if e[0] != key]
			prefs.overpassServerJson = json.dumps(data)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_reset_overpass_server(Operator):

	bl_idname = "bgis.reset_overpass_server"
	bl_description = '重置为默认 Overpass 服务器'
	bl_label = "重置"
	bl_options = {'INTERNAL'}

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		prefs.overpassServerJson = json.dumps(DEFAULT_OVERPASS_SERVER)
		context.area.tag_redraw()
		return {'FINISHED'}

class BGIS_OT_edit_overpass_server(Operator):

	bl_idname = "bgis.edit_overpass_server"
	bl_description = '编辑 Overpass 服务器 URL'
	bl_label = "编辑"
	bl_options = {'INTERNAL'}

	url: StringProperty(name = "URL 模板",  description = "定义Overpass服务器的URL端点")
	name: StringProperty(name = "描述", description = "为此服务器选择一个合适的名称")
	desc: StringProperty(name = "描述", description = "添加关于此远程服务器的描述或注释")

	def invoke(self, context, event):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.overpassServer
		if key == '':
			return {'CANCELLED'}
		data = json.loads(prefs.overpassServerJson)
		entry = [entry for entry in data if entry[0] == key][0]
		self.url, self.name, self.desc = entry
		return context.window_manager.invoke_props_dialog(self)

	def execute(self, context):
		prefs = context.preferences.addons[PKG].preferences
		key = prefs.overpassServer
		data = json.loads(prefs.overpassServerJson)
		data = [entry for entry in data if entry[0] != key] #deleting
		data.append((self.url, self.name, self.desc))
		prefs.overpassServerJson = json.dumps(data)
		context.area.tag_redraw()
		return {'FINISHED'}


classes = [
BGIS_OT_pref_show,
BGIS_PREFS,
BGIS_OT_add_predef_crs,
BGIS_OT_rmv_predef_crs,
BGIS_OT_reset_predef_crs,
BGIS_OT_edit_predef_crs,
BGIS_OT_add_osm_tag,
BGIS_OT_rmv_osm_tag,
BGIS_OT_reset_osm_tags,
BGIS_OT_edit_osm_tag,
BGIS_OT_add_dem_server,
BGIS_OT_rmv_dem_server,
BGIS_OT_reset_dem_server,
BGIS_OT_edit_dem_server,
BGIS_OT_add_overpass_server,
BGIS_OT_rmv_overpass_server,
BGIS_OT_reset_overpass_server,
BGIS_OT_edit_overpass_server
]

def register():
	for cls in classes:
		try:
			bpy.utils.register_class(cls)
		except ValueError as e:
			#log.error('Cannot register {}'.format(cls), exc_info=True)
			log.warning('{} is already registered, now unregister and retry... '.format(cls))
			bpy.utils.unregister_class(cls)
			bpy.utils.register_class(cls)

	# set default cache folder
	prefs = bpy.context.preferences.addons[PKG].preferences
	if prefs.cacheFolder == '':
		prefs.cacheFolder = APP_DATA


def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)
