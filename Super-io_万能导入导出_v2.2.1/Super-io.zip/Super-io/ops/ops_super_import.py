from __future__ import annotations

import os.path
import sys

import bpy
from bpy.props import (StringProperty)

from .dynamic_io import IO_Base
from .core import MeasureTime, ConfigItemHelper, ConfigHelper
from .core import get_pref_attr

from ..preferences.data_icon import G_ICON_ID
from ..preferences.data_config_store import get_config_list


def capture_dispatch_context(context):
    return {
        'window': getattr(context, 'window', None),
        'screen': getattr(context, 'screen', None),
        'area': getattr(context, 'area', None),
        'region': getattr(context, 'region', None),
    }


def run_in_dispatch_context(context, dispatch_context, callback):
    override = {key: value for key, value in dispatch_context.items() if value is not None}
    if not override:
        return callback(context)

    try:
        override_context = context.temp_override(**override)
    except Exception:
        return callback(context)

    try:
        override_context.__enter__()
    except Exception:
        return callback(context)

    try:
        result = callback(bpy.context)
    except Exception:
        override_context.__exit__(*sys.exc_info())
        raise
    else:
        override_context.__exit__(None, None, None)
        return result


def get_remaining_import_files(file_list, match_file_op_dict, primary_ext):
    remain_list = []
    seen_files = set()
    primary_ext = (primary_ext or '').lower()

    for file in file_list:
        file_ext = file.split('.')[-1].lower()
        should_remain = file not in match_file_op_dict or file_ext != primary_ext
        if should_remain and file not in seen_files:
            remain_list.append(file)
            seen_files.add(file)

    return remain_list


class SuperImport(IO_Base, bpy.types.Operator):
    """Paste Model/Images"""
    bl_label = "Super Import"
    bl_options = {"UNDO_GROUPED"}

    # Build-in
    ############
    def invoke(self, context, event):
        self.restore()
        dispatch_context = capture_dispatch_context(context)

        from ..clipboard.clipboard import Clipboard as Clipboard
        # get Clipboard
        self.clipboard = Clipboard()
        file_list = self.clipboard.pull_files_from_clipboard(
            force_unicode=get_pref_attr('force_unicode', False)
        )

        del self.clipboard  # release clipboard

        if len(file_list) == 0:
            self.report({"ERROR"}, "No file found in clipboard!")
            return {"FINISHED"}

        for file_path in file_list:
            if os.path.isdir(file_path):
                self.dir_list.append(file_path)  # add dir list for batch import folder's files
                continue
            elif not os.path.exists(file_path):
                self.report({"ERROR"}, f"{file_path} not exist!")

            # pass extra file
            extension = file_path.split('.')[-1].lower()
            if extension in {'mtl'}:
                continue

            self.file_list.append(file_path)
        # count ext type
        ext_list = [file.split('.')[-1].lower() for file in self.file_list]
        # report if more than one extension is selected
        if len(set(ext_list)) > 1:
            self.report({"WARNING"}, "More than one format of file is copied!")
            # return {"CANCELLED"}
        ext_count_dict = dict()

        for ext in ext_list:
            if ext not in ext_count_dict:
                ext_count_dict[ext] = 1
            else:
                ext_count_dict[ext] += 1

        # set the main ext
        for key, value in ext_count_dict.items():
            if (value == max(ext_count_dict.values())):
                self.ext = key
                break

        # call for match configs
        self.CONFIGS = ConfigHelper(check_use=True, filter=self.ext, io_type='IMPORT')

        # import default if not custom config for this file extension
        if self.CONFIGS.is_empty():
            self.use_custom_config = False

            if self.ext == 'blend':
                run_in_dispatch_context(context, dispatch_context, self.import_blend_default)
                return {'FINISHED'}
            else:
                return run_in_dispatch_context(context, dispatch_context, self.execute)

        self.use_custom_config = True

        return run_in_dispatch_context(context, dispatch_context, self.import_custom_dynamic)

    def execute(self, context):
        with MeasureTime() as start_time:
            self.import_default(context)
            self.report_time(start_time)

        return {"FINISHED"}

    # Import Method (Popup)
    def import_custom_dynamic(self, context):
        # unregister_class
        self.unregister_dep_classes()
        self.dep_classes.clear()

        # no match list
        file_list = self.file_list
        dir_list = self.dir_list
        # match dict
        match_file_op_dict = dict()
        # match index :exclude from popup importer
        match_index_list = list()

        for index in self.CONFIGS.index_list:
            # set config for register
            config_item = get_config_list(context)[index]
            ITEM = ConfigItemHelper(config_item)
            if not ITEM.is_config_item_poll(context.area.type): continue

            match_files = ITEM.get_match_files(file_list)

            if len(match_files) > 0:
                for file in match_files:
                    match_file_op_dict[file] = ITEM
                match_index_list.append(index)

        # dynamic operator
        ##################
        from .dynamic_io import DynamicImport
        from ..imexporter.default_importer import get_importer

        importer = get_importer()

        for index in self.CONFIGS.index_list:
            if index in match_index_list: continue  # not register those match config
            # only for register
            config_item = get_config_list(context)[index]
            ITEM = ConfigItemHelper(config_item)
            if not ITEM.is_config_item_poll(context.area.type): continue

            op_cls = type("DynOp",
                          (bpy.types.Operator,),
                          {"bl_idname": f'wm.spio_config_{index}',
                           "bl_label": ITEM.name,
                           "bl_description": ITEM.description,
                           "execute": DynamicImport.execute,
                           # custom pass in
                           'ITEM': ITEM,
                           'file_list': file_list,
                           'dir_list': dir_list,
                           'match_file_op_dict': match_file_op_dict,
                           },
                          )

            self.dep_classes.append(op_cls)

        # register
        self.register_dep_classes()

        ############################
        # execute
        ############################

        # first import all matching rule files
        if len(match_file_op_dict) > 0:
            with MeasureTime() as start_time:
                for filepath, item_helper in match_file_op_dict.items():
                    op_callable, ops_args, op_context = item_helper.get_operator_and_args()
                    call_args = ops_args.copy()
                    call_args[item_helper.get_file_argument_name()] = filepath
                    try:
                        if op_context:
                            op_callable(op_context, **call_args)
                        else:
                            op_callable(**call_args)

                    except Exception as e:
                        self.report({"ERROR"}, str(e))

                if get_pref_attr('report_time', True): self.report_time(start_time)

        # then popup menu to select the remain not matching file
        remain_list = get_remaining_import_files(file_list, match_file_op_dict, self.ext)

        # menu title
        if len(match_file_op_dict) > 0:
            title = f'Match {self.ext.upper()} import finish (Import {len(match_file_op_dict)} files)'
        else:
            title = f'Super Import {self.ext.upper()}'

        if len(remain_list) > 0:
            # set draw menu
            from .core import PopupImportMenu
            import_op = self
            ext = self.ext
            target_context = context

            def draw_custom_menu(self, context):
                layout = self.layout
                if len(match_file_op_dict) > 0:
                    layout.label(text=f'Remain {len(remain_list)} files')

                if len(import_op.dep_classes) > 0:
                    for cls in import_op.dep_classes:
                        layout.operator(cls.bl_idname)

                layout.separator()
                # default popup
                if ext in importer:
                    layout.operator('spio.import_model').files = '$$'.join(
                        remain_list)
                elif ext == 'blend':
                    pop = PopupImportMenu(file_list=remain_list,
                                          dir_list=dir_list,
                                          context=target_context)
                    menu = pop.default_blend_menu(return_menu=True)
                    if menu: menu(self, target_context)
                else:
                    pop = PopupImportMenu(file_list=remain_list,
                                          dir_list=dir_list,
                                          context=target_context)
                    menu = pop.default_image_menu(return_menu=True)
                    if menu: menu(self, target_context)

            context.window_manager.popup_menu(draw_custom_menu, title=title, icon='FILEBROWSER')

        return {'FINISHED'}


class WM_OT_super_import(SuperImport):
    """Load files/models/images from clipboard"""
    bl_idname = "wm.super_import"
    bl_label = "Super Import"

    def import_blend_default(self, context):
        """Import with default popup"""
        from .core import PopupImportMenu
        popup = PopupImportMenu(file_list=self.file_list,
                                dir_list=self.dir_list,
                                context=context)
        popup.default_blend_menu()

    def import_default(self, context):
        from ..imexporter.default_importer import get_importer

        importer = get_importer()

        ext = self.ext
        if ext in importer:
            for file_path in self.file_list:
                bl_idname = importer.get(ext)
                op_callable = getattr(getattr(bpy.ops, bl_idname.split('.')[0]), bl_idname.split('.')[1])
                op_callable(filepath=file_path)
        else:
            from .core import PopupImportMenu

            popup = PopupImportMenu(self.file_list, self.dir_list, context)
            popup.default_image_menu()


def file_context_menu(self, context):
    layout = self.layout
    layout.operator('wm.super_import', icon_value=G_ICON_ID['import'])
    layout.separator()


def node_context_menu(self, context):
    layout = self.layout
    layout.operator('node.spio_import', icon_value=G_ICON_ID['import'])
    layout.separator()


def register():
    bpy.utils.register_class(WM_OT_super_import)

    # Global ext
    bpy.types.Scene.spio_ext = StringProperty(name='Filter extension', default='')
    bpy.types.WindowManager.spio_cache_import = StringProperty()
    # Menu append
    # bpy.types.NODE_MT_context_menu.prepend(node_context_menu)


def unregister():
    # bpy.types.NODE_MT_context_menu.remove(node_context_menu)

    bpy.utils.unregister_class(WM_OT_super_import)

    del bpy.types.Scene.spio_ext
    del bpy.types.WindowManager.spio_cache_import
